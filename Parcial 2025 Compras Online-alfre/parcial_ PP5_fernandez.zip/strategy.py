
""" los productos pueden tener modificadores que afectan 

-precio venta
-costo de envío:


● Promoción: reduce el "precio de venta" del producto en un porcentaje determinado.


● Pesado:  agrega a su "precio de venta" un extra por envío en $3000.


# NECSITO USUARIO
● Tax-Free: disponible solo para "usuarios extranjeros", elimina el agregado de IVA al "precio de
venta" del producto. 

Todos los productos que no tengan este modificador se agregara el IVA
del 21% sobre el precio base.

"""

#le tengo q pasar monto a sumar al producto con un metodo ->sumar_modificador()



from abc import ABC,abstractmethod
class Estrategia_Modificador(ABC):

    @abstractmethod
    def sumar_modificador(self,precio:int,usuario):
        pass
    
    
    
class Promocion(Estrategia_Modificador):# reduce el "precio de venta" del producto en un porcentaje determinado.
    def __init__(self,porcentaje:float):
        super().__init__()
        self.porcentaje=porcentaje  
        
        
    def sumar_modificador(self,precio:int,usuario):
        self.precio-= (precio*self.porcentaje)
        return self.precio
                
    

    
class Pesado(Estrategia_Modificador):
    def sumar_modificador(self,precio:int,usuario):#extra por envío en $3000.
        return precio+3000
        
        
        
        #TENGO Q PREGUNTAR SI ES EXTRANGERO ??? SOLOPARA ESOS APLOCA
        
class Taxfree(Estrategia_Modificador):
    def sumar_modificador(self,precio:int,usuario): #ver IVA EN PRODUCTO
        return precio 
        

        

        