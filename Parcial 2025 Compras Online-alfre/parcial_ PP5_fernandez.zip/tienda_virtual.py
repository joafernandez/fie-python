

""" Tienda Virtual
 conoce :
- todos los usuarios 
- todos los productos

tienda debe poder:

1) Gestionar venta: dado un usuario con productos en su carrito, permite la compra().
Si el usuario es menor y lleva bebidas alcohólicas se las retira del carrito y las pone() nuevamente en
los productos disponibles.

2) Gestionar la morosidad: aplica descuento() de 100 puntos a los usuarios con saldo negativo."""


from usuario import Usuario

class Tienda:
    def __init__(self):
        self.lista_usuario=[]#agregar
        self.lista_producto=[] #agregar
        
        
    def agregar_usuario(self,usuario):
        self.lista_usuario.append(usuario)
        
    
    def agregar_producto(self,usuario):
        self.lista_producto.append(usuario)
        
        
        
    def comprar(self,usuario):
        usuario.comprar()
       
       
    
    def morosidad(self):
        pass
    
    
    
        
    
    
    
    