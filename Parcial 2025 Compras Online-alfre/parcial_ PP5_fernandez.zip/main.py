
# crear :

from tienda_virtual import Tienda     
from usuario import Usuario
from producto import Indumentaria, Bebida, Mueble
from strategy import Pesado, Taxfree, Promocion
from strategy_niveles import Oro, Plata, Bronce



def main():
    
    tiendita = Tienda()
    
    mueble= Mueble("cama",6000)
    
    usuario1 =Usuario("joana",34,extrangero=False)  #usuario puede: ingresra slado, comprar y agregar producto
    usuario1.ingresar_saldo(7000)

    tiendita.agregar_usuario(usuario1)
    
    
    mueble.agregar_modficador(Pesado())
    mueble.agregar_modficador(Promocion(30))
    
    usuario1.agregar_producto(mueble)
    
    print("saldo despues",usuario1.saldo_inicial)
    
    usuario1.comprar()
    
    print("saldo despues de comprar",usuario1.saldo_inicial)
    print ("puntos",usuario1.puntos)
    
    usuario1.puntos=16000
    usuario1.actualizar()
    
    print ("puntos",usuario1.puntos)
    
    
    
 
    
  
    
   
    
    
    
        

